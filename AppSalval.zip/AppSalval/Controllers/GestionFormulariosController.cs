﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSalval.Controllers
{
    class GestionFormulariosController
    {
        public void HandleOpcionesClicked()
        {
            // Lógica para desplegar opciones
            Console.WriteLine("Opciones clicked.");
        }

        public void HandleMenuPrincipalClicked()
        {
            // Lógica para salir al menú principal
            Console.WriteLine("Menú Principal clicked.");
        }
    }

}
